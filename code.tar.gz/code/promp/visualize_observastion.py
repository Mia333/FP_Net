#!/usr/bin/env python
"""
File used for debugging/ testing, visualize the training dataset or observations, i.e. data saved in '.mat' files.
K. Yao, kunpeng.yao@tum.de
Last modified: 26 Sep. 2017
"""

import rospy
import numpy as np
from rospy.numpy_msg import numpy_msg
import scipy.io as sio
from rospy_tutorials.msg import Floats
from std_msgs.msg import String, Int32
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D, proj3d
import scipy
import math
from qualisys.msg import Marker, Markers, Subject
import copy
import json
import scipy.io as sio
import os



def delete_trajectory(mat_path, traj_number):
	'''
	mat_path: path to the .mat file
	traj_number: the trajectory to delete
	'''
	temp_data = sio.loadmat(mat_path)
	TrajList = temp_data['TrajList']
	print 'Original Size: ', TrajList.shape
	TrajList = np.delete(TrajList, traj_number, axis=0)
	print 'Current Size: ', TrajList.shape
	sio.savemat(mat_path, {'TrajList': TrajList})



def visualize_mat(mat_path):
	'''
	Visualize the data saved in .mat file under the mat_path.
	'''
	temp_data = sio.loadmat(mat_path)
	temp_data = temp_data['TrajList']

	temp_data = list(temp_data)
	TrialNumber = len(temp_data)
	datasets_train = None # reset saved training datasets
	print 'TrialNumber: ', TrialNumber
	fig = plt.figure(0)
	ax = fig.gca(projection='3d')

	for i in range(TrialNumber): # 0, 1, ..., TrialNumber-1
		data = np.transpose(temp_data[i]) # 'numpy.ndarray', (3,51)
		temp_datadict = {'Y':np.reshape(data.flatten(1),(data.flatten(1).shape[0],1)), 'Ymat':data} # ['Y']: (153,1), ['Ymat']: (3,51)
		
		if datasets_train is None:
			datasets_train = np.array([temp_datadict])
		else:
			datasets_train = np.append(datasets_train, [temp_datadict], axis=0)

			ax.scatter(data[0], data[1], data[2], c = 'k', s = 3, alpha = 0.3)
			ax.text(data[0][-1], data[1][-1], data[2][-1], str(i), color='red')

	plt.title('Recorded Training Trajectories')
	ax.set_xlabel('X')
	ax.set_ylabel('Y')
	ax.set_zlabel('Z')
	ax.view_init(30,120)
	plt.show()


if __name__ == '__main__':
	
	dir_path = os.path.dirname(os.path.realpath(__file__))
	joint = 'WR' # specified the filder name
	target = '3' # to delete: target 3
	mat_path = dir_path + '/data/' + joint + '/' + target + '/training_dataset.mat' # should specify the name of .mat file

	visualize_mat(mat_path)

	# Delete the trajectory in the observation (saved '.mat' file) by specifying the traj. number.
	# delete_trajectory(mat_path, 21)
	# visualize_mat(mat_path)