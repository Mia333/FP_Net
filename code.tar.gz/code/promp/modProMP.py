#!/usr/bin/env python
"""
The module that contains the realization of ProMP algorithm.
K. Yao, kunpeng.yao@tum.de
Last modified: 26 Sep. 2017
BP: Last modified 30 Oct. 2017
"""
#NOT NEEDED: import rospy
import numpy as np
import scipy.io as sio
#NOT NEEDED from std_msgs.msg import String, Int32
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D, proj3d
import numpy.matlib
#NOT NEEDED from qualisys.msg import Marker, Markers, Subject
#NOT NEEDED: from rospy_tutorials.msg import Floats
#NOT NEEDED: from rospy.numpy_msg import numpy_msg
import os
import json
from scipy import interpolate
import copy


class classProMP(object):
    # --------------------------------------------------
    TrialNumber = None # number of recorded demonstrations
    DoF = 3
    nder = 1
    numGaussians = 20
    lambdaProMPs = 2*1e-5
    # T = 51 # trajectory length
    # --------------------------------------------------
    motion = 0 # motion type: making prediction: motion == 1, update model: motion == 2
    marker_0 = None
    marker_1 = None
    obs_single = None # single observation
    obs_list = None # a list of saved observation
    # --------------------------------------------------
    ProMPsPrior = None
    TrajPrior = None # prior distribution of current updated trajectory
    omega = None # parameters of prior ProMP
    Sigma = None
    pred_omega = None # parameters of predicted ProMP
    pred_Sigma = None
    datasets_train = None # training dataset
    datasets_test = None # testing dataset
    TrajList = [] # save down-sampled observation trajectories

    # --------------------------------------------------
    def __init__(self, config_file, joint_name, target_name, topic_name_0=None, topic_name_1=None, T=51):
        self.T = T
        
        dir_path = os.path.dirname(os.path.realpath(__file__))
        path_to_json = dir_path + '/config/' + config_file +'.json'

        with open(path_to_json) as data_file:
            config_data = json.load(data_file)
        self.scaling_ratio = float(config_data['scaling_ratio']) # Decide if scaling of the Qualisys data is required. 1: shoud divide 1000.0 in the callback functions; 0: not required.

        # target_name: integar, 0, 1,..., specify the target of the model. One model for each target.
        self.joint_name = joint_name # the joint_name of this joint
        self.target = target_name
        self.filepath = dir_path + '/data/' + joint_name + '/' + str(self.target) + '/' # path to the training data

        #NOT NEEDED: self.subMotionStatus = rospy.Subscriber('/motion_status', Int32, self.cb_motion_status)
        #NOT NEEDED: self.subMarker0 = rospy.Subscriber(topic_name_0, Marker, self.cb_marker_0)
        # self.subMarker1 = rospy.Subscriber(topic_name_1, Marker, self.cb_marker_1) # Add Marker1 to increase the robustness, in case Marker0 fails. If Marker1 is added, the used marker position is calculated as the middle of Marker0 and Marker1.
        
        if os.path.isfile(self.filepath+'observation.mat'): # Delete the old 'observation.mat' file (if exist) before initializing the node, hence the previous observations will not affect the new model.
            os.remove(self.filepath+'observation.mat')



    '''---------- Callback Functions ----------'''
    def cb_motion_status(self, msg):
        self.motion = msg.data



    def cb_marker_0(self, msg):
        self.marker_0 = np.array([msg.position.x/self.scaling_ratio, msg.position.y/self.scaling_ratio, msg.position.z/self.scaling_ratio])



    # def cb_marker_1(self, msg):
    #     self.marker_1 = np.array([msg.position.x/self.scaling_ratio, msg.position.y/self.scaling_ratio, msg.position.z/self.scaling_ratio])



    '''---------- Functional Functions ----------'''
    def load_data(self, filepath, filename):
        data_list = sio.loadmat(filepath+filename)
        data_list = data_list['TrajList']
        data_list = list(data_list)
        return data_list # list, (N, 3, 51), N = len(data_list) is the number of trials, data_list[0]: (51*3), ndarray, data for each trial



    def process_training_data(self, data=None, filepath=None, _plot_=False):
        if data is None:
            if filepath == None:
            	filepath = self.filepath
            temp_data = self.load_data(filepath, 'training_dataset.mat') # Load training dataset, temp_data is ndarray, should be changed to list, temp_data[i] is the (i+1)_th training data trial, of shape (51, 3).
        else:
            temp_data = data
    
        # print(np.asarray(temp_data).shape)
        # raise Exception
        # print(temp_data[0])
        self.TrialNumber = len(temp_data)
        self.datasets_train = None # Reset saved training datasets
        if _plot_:
            fig = plt.figure(0)
            ax = fig.gca(projection='3d')
            sum_posS = np.zeros((3,)) # save the start positions of each trial
            sum_posT = np.zeros((3,)) # save the end positions of each trial
        for i in range(self.TrialNumber): # 0, 1, ..., TrialNumber-1
            data = np.transpose(temp_data[i]) # 'numpy.ndarray', (3,51)
            temp_datadict = {'Y': np.reshape(data.flatten(1),(data.flatten(1).shape[0],1)), 'Ymat': data} # ['Y']: (153,1), ['Ymat']: (3,51)
            if self.datasets_train is None:
                self.datasets_train = np.array([temp_datadict])
            else:
                self.datasets_train = np.append(self.datasets_train, [temp_datadict], axis=0)
            if _plot_:
                sum_posS += data[:, 0]
                sum_posT += data[:,-1]
                ax.scatter(data[0], data[1], data[2], c = 'k', s = 3, alpha = 0.3)
        if _plot_:
            sum_posS = sum_posS/float(self.TrialNumber)
            sum_posT = sum_posT/float(self.TrialNumber)
            ax.scatter(sum_posS[0], sum_posS[1], sum_posS[2], c = 'r', s = 100) # plot start position
            ax.scatter(sum_posT[0], sum_posT[1], sum_posT[2], c = 'g', s = 100) # plot end position
            plt.title('Recorded Training Trajectories of Model '+self.joint_name+' Target '+str(self.target+1))
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('Z')
            ax.view_init(30,120)
            plt.show()
        return True



    def update_model(self, _plot_=False, _update_ = True):
        '''
        Load both 'training_dataset.mat' and saved 'observation.mat', retrain the model.
        '_update_': bool, if True: do update, otherwise, do not update and just return the prior traj.
        '''
        training_data = self.load_data(self.filepath, 'training_dataset.mat') # (N_train, 3) # load local training file
        if _update_:
            observed_data = self.load_data(self.filepath, 'observation.mat') # (N_obs, 3)
            merged_data = training_data+observed_data # list, length: (N_train + N_obs), each element: (3, self.T)
        else:
            merged_data = training_data
        total_trial = len(merged_data) # total number of trials
        # --------------------------------------------------
        self.datasets_train = None # reset training datasets
        for i in range(total_trial): # 0, 1, ..., total_trial-1
            data = np.transpose(merged_data[i]) # 'numpy.ndarray', (3, 51)
            temp_datadict = {'Y': np.reshape(data.flatten(1), (data.flatten(1).shape[0],1)), 'Ymat': data} # ['Y']: (153,1), ['Ymat']: (3,51)

            if self.datasets_train is None:
                self.datasets_train = np.array([temp_datadict])
            else:
                self.datasets_train = np.append(self.datasets_train, [temp_datadict], axis=0)
            self.datasets_train[i]['PSI_X'] = self.getBasisFunctionsMultipleJointsAndTimeSteps(self.numGaussians, self.T, self.DoF, self.nder) # self.datasets_train[i][PSI_X]: (153, 60) <type 'numpy.ndarray'> # Obtain PSI_X matrices for training datasets
        # --------------------------------------------------
        self.ProMPsPrior = self.ProMPs_train(self.datasets_train, self.datasets_train[0]['PSI_X'].shape[1], self.datasets_train[0]['Y'].shape[1], self.lambdaProMPs) # (N,), 60, 1, ...
        self.omega = np.mean(self.ProMPsPrior,2)
        self.Sigma = np.cov(np.squeeze(self.ProMPsPrior[:,0,:]))
        if True:
            prior_mtx = self.ProMPs_plot_prior(self.datasets_train, self.ProMPsPrior, self.lambdaProMPs, 0, self.DoF, self.nder)
        return prior_mtx


    def train_prior_model(self, _plot_=False):
        '''
        Train the prior model using the data in 'training_dataset.mat'.
        '''
        for t in range(self.TrialNumber): # get basis functions
            self.datasets_train[t]['PSI_X'] = self.getBasisFunctionsMultipleJointsAndTimeSteps(self.numGaussians, self.T, self.DoF, self.nder) # self.datasets_train[l][PSI_X]: (153, 60) <type 'numpy.ndarray'>
        self.ProMPsPrior = self.ProMPs_train(self.datasets_train, self.datasets_train[0]['PSI_X'].shape[1], self.datasets_train[0]['Y'].shape[1], self.lambdaProMPs) # (40,), 60, 1, ...
        self.omega = np.mean(self.ProMPsPrior,2)
        self.Sigma = np.cov(np.squeeze(self.ProMPsPrior[:,0,:]))
        self.ProMPs_plot_prior(self.datasets_train, self.ProMPsPrior, self.lambdaProMPs, 1, self.DoF, self.nder, extra_figure = _plot_)
        return True



    def append_observation(self):
        '''
        Save an observation in "obs_single" and append it to "obs_list".
        '''
        # if (self.marker_0 is None) or (self.marker_1 is None):
        if False:
            pass
        else:
            # self.obs_single = np.reshape(np.array((self.marker_0 + self.marker_1)/2) , (1,3)) # (3,)
            self.obs_single = np.reshape(np.array(self.marker_0) , (1,3)) # (3,)
            if self.obs_list is None:
                self.obs_list = self.obs_single
            else:
                self.obs_list = np.append(self.obs_list, self.obs_single, axis=0)



    def save_motion_trial(self):
        '''
        Down sample the saved "obs_list" to length 'self.T' and save the down-sampled trial data to local file.
        '''
        orig_len = self.obs_list.shape[0] # obs_list: (orig_len * 3) # [TODO] Extend to 3*multiple joints
        x = self.obs_list[:,0]
        y = self.obs_list[:,1]
        z = self.obs_list[:,2]
        t = np.arange(0, orig_len)
        f_x = interpolate.interp1d(t, x)
        f_y = interpolate.interp1d(t, y)
        f_z = interpolate.interp1d(t, z)
        t_new = np.linspace(0, orig_len-1, num=self.T)
        x_down = f_x(t_new) # orig_len * 1
        y_down = f_y(t_new) # orig_len * 1
        z_down = f_z(t_new) # orig_len * 1
        traj_cut = np.array([x_down,y_down,z_down])  # orig_len * 3
        traj_cut = np.transpose(traj_cut) # (51,3)
        
        if not os.path.isfile(self.filepath+'observation.mat'): # If 'observation.mat' does not exist, then save the trajectory as a new file.
            self.TrajList.append(traj_cut) # len(self.TrajList) = 1
            self.TrajList = np.array(self.TrajList) # (1,51,3)
        else:
            self.TrajList = self.load_data(self.filepath, 'observation.mat') # already exists, then first load file, then append the new trial at the end of the list
            self.TrajList.append(traj_cut) # len(self.TrajList) * 3, append the new trajectory, TrajList[i-1] should be the i_th trajectory (51*3)
            self.TrajList = np.array(self.TrajList) # (1,51,3)
        sio.savemat(self.filepath+'observation.mat', {'TrajList': self.TrajList})
        return True



    def ProMPs_plot_prior(self, datasets, wsProMPs, lambdaProMPs, flagPlotData, DoF, nder, extra_figure = False):
        '''
        Plot prior distribution for each DoF.
        '''
        ProMPsPrior = np.mean(wsProMPs,2)
        sigmaProMPs = np.cov(np.squeeze(wsProMPs[:,0,:])) # sigmaProMPs = np.cov(np.transpose(np.squeeze(wsProMPs[:,0,:])))
        # print(sigmaProMPs.shape)
        y_predProMPs = np.dot(datasets[0]['PSI_X'], ProMPsPrior) # (153,1)
        y_predProMPs = y_predProMPs[::nder,:] # only plot the 0th derivative
        y_predVarProMPs = np.zeros(y_predProMPs.shape)
        for t in np.arange(1, y_predProMPs.shape[0]*nder+1, nder):
            k = int((t+nder-1)/float(nder)) # 1, 2, ..., 153
            y_predVarProMPs[k-1,:] = np.dot(np.dot(datasets[0]['PSI_X'][t-1,:],sigmaProMPs),np.transpose(datasets[0]['PSI_X'][t-1,:])) + lambdaProMPs
        T = y_predProMPs.shape[0]/DoF # for each task different number of timesteps
        y_predProMPs = np.reshape(y_predProMPs,(T,DoF))
        y_predVarProMPs = np.reshape(y_predVarProMPs,(T,DoF))

        self.TrajPrior = y_predProMPs # save generated prior trajectory
        
        if extra_figure:
            timeIds = np.linspace(0,1,T)
            L = datasets.shape[0] # datasets.shape (40,)
            # --------------------------------------------------
            fig = plt.figure()
            ax = fig.gca(projection='3d')

            ax.plot(y_predProMPs[:,0], y_predProMPs[:,1], y_predProMPs[:,2], c = 'k', linewidth = 3)
            ax.scatter(y_predProMPs[0,0], y_predProMPs[0,1], y_predProMPs[0,2], c = 'r', s = 100) # scatter the start position
            ax.scatter(y_predProMPs[-1,0], y_predProMPs[-1,1], y_predProMPs[-1,2], c = 'g', s = 100) # scatter the start position
            # [TODO] error_plot = np.sqrt(y_predVarProMPs[:,i])
            # [TODO] ax_plot[i].fill_between(timeIds, mean_plot-error_plot, mean_plot+error_plot, alpha=0.2, edgecolor='#1B2ACC', facecolor='#089FFF', linewidth=4, antialiased=True)
            if flagPlotData > 0:
                for trajId in range(L):
                    Tdata = datasets[trajId]['Y'].shape[0]/DoF
                    y_true = np.reshape(datasets[trajId]['Y'],(Tdata,DoF))
                    ax.plot(y_true[:,0], y_true[:,1], y_true[:,2], c = 'b', alpha = 0.3)
            plt.title('Prior Trajectory Distribution of Model '+self.joint_name+' Target '+str(self.target+1), fontsize = 17)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('Z')
            ax.view_init(30,120)
            plt.show()
            plt.close(fig)
            return True
        else:
            return y_predProMPs


    

    '''---------- Core Functions of ProMP ----------'''
    def createBasisFunParams(self, numFuns): # numFuns=20
        if numFuns > 5:
            p = float(1)/(numFuns-3)
            c = np.append(np.append([0-p], np.linspace(0,1,numFuns-2), axis=0), [1+p], axis=0)
        else:
            c = np.linspace(0,1,numFuns) # shape: (numFuns,), type: 'numpy.ndarray'
        if numFuns > 1:
            h = np.power(2*0.5*(c[1]-c[0]),2)
        else:
            h = 1
        return c, h



    def getBasisFunctions(self, numBasisFuns, timesteps, nder): # 20, 51, 1
        [c,h] = self.createBasisFunParams(numBasisFuns) # c.shape: (20,)
        c = np.kron( np.ones((1,timesteps)), np.reshape(np.transpose(c),(c.shape[0],1)) ) # (20,51)
        z = np.linspace(0,1,timesteps) # (51,)
        dz_dt = z[1]-z[0]
        z = np.matlib.repmat(z,numBasisFuns,1) # (20,51)
        phi = np.zeros([nder,numBasisFuns,timesteps]) # (1,20,51)
        b = np.exp(-1*np.power((z-c),2) / (2*h)) # [Eq.2] # (20,51) # compute stroke based basis functions for each timestep
        sum_b = np.matlib.repmat(np.sum(b,axis=0),numBasisFuns,1) # compute derivatives: phi_dot= phi' * z' (with approximation)
        phi[0,:,:] = np.divide(b,sum_b)
        if nder>=2:
            db_dz = np.divide(np.multiply(b,(c-z)),h) # elementwise (20,51)
            sum_db_dz = np.kron(np.ones((numBasisFuns,1)), np.sum(db_dz,axis=0)) # (20,51)
            dphi_dz = np.divide((np.multiply(db_dz,sum_b)-np.multiply(b,sum_db_dz)), np.power(sum_b,2)) # (20,51)
            dphi_dt = np.dot(dphi_dz,dz_dt) # (20,51)
            phi[1,:,:] = dphi_dt
            if nder==3:
                I = np.ones([numBasisFuns,timesteps])
                d2b_dz2 = np.multiply(b, (np.dot(np.power((c-z),2), np.linalg.inv(np.power(h,2))) - np.linalg.inv(h)))
                A = np.multiply(db_dz,sum_b) # (20,51)
                B = np.multiply(b,sum_db_dz) # (20,51)
                C = np.power(sum_b,2) # (20,51)
                dA = np.dot(dz_dt, (np.multiply(d2b_dz2,sum_b) + np.multiply(sum_db_dz,db_dz))) # (20,51)
                sum_d2b_dz2 = np.kron(np.ones((numBasisFuns,1)), np.sum(d2b_dz2,axis=0))
                dB = np.dot(dz_dt, (np.multiply(sum_d2b_dz2,b) + np.multiply(db_dz,sum_db_dz))) # (20,51)
                dC = np.multiply(2*np.dot(dz_dt,sum_db_dz),sum_b) # (20,51)
                d2phi_dt2 = np.divide(np.dot(dz_dt, (np.multiply((dA-dB),C)-np.multiply((A-B),dC))), (np.power(C,2)))
                phi[2,:,:] = d2phi_dt2
        return phi



    def getBasisFunctionsMultipleJointsAndTimeSteps(self, numBasisFuns, T, DoF, nder):
        '''
        Gets only the Basisfunctions for multiple joints and timesteps.
        numBasisFuns: number of basisfunctions
        T: number of Timesteps
        DoF: number of joints
        nder: number of derivatives
        '''
        psi = self.getBasisFunctions(numBasisFuns, T, nder) # (1,20,51)
        PSI_X = np.zeros([nder*DoF*T, numBasisFuns*DoF]) # (153, 60)
        for t in range(T):
            actual = np.squeeze(psi[:,:,t])
            for j in range(DoF):
                PSI_X[((nder*j+1+nder*DoF*t)-1):(nder*(j+1)+nder*DoF*t), ((j*numBasisFuns+1)-1):(numBasisFuns*(j+1))] = actual
        return PSI_X



    def ProMPs_train(self, datasets, M, N, lambdaProMPs):
        '''
        Get the coefficient matrix w[:,:,i].
        '''
        L = datasets.shape[0] # num of trajectories
        w = np.zeros([M,N,L])
        for i in range(L):
            X_train = datasets[i]['PSI_X'] # (153,60)
            y_train = datasets[i]['Y'] # (153,1)
            temp = np.dot(np.transpose(X_train), X_train) + np.eye(M)*lambdaProMPs # lambdaProMPs = 2e-05
            temp = np.dot(np.linalg.inv(temp), np.transpose(X_train))
            w[:,:,i] = np.dot(temp, y_train)
        return w



    '''---------- Functions for Making Prediction ----------'''
    def make_prediction(self, _plot_=False):
        '''
        Make prediction using conditioning based on current observation points "obs_list".
        '''
        # datasets_test = self.obs_list # (N,)
        # obs_num = self.obs_list.shape[0]
        datasets_test = self.obs_list[-(self.nder+1):] # Only use the last (self.nder+1) observations to make prediction, make sure that diff. can be calculated.
        obs_num = datasets_test.shape[0]

        # if obs_num >= self.T: # Incase the num. of observation is larger than the sampled length of traj.
        #     datasets_test = self.obs_list.take(map(int, np.linspace(0, obs_num-1, self.T)), axis=0)
        #     obs_num = self.T

        usedSampleIds = np.arange(1, obs_num, 1)
        lambdaProMPsPrediction = np.append([np.array([self.lambdaProMPs])], 2*np.ones([1,self.DoF-1]), axis=1) # [2.00e-05, 2.0, 2.0] only condition on the first DoF
        # obtain 'PSI_X' and 'Y' for 'datasets_test'
        temp_datadict = {'Y':np.reshape(datasets_test.flatten(1), (datasets_test.flatten(1).shape[0],1)), 'Ymat':datasets_test}
        temp_datadict['PSI_X'] = self.getBasisFunctionsMultipleJointsAndTimeSteps(self.numGaussians, obs_num, self.DoF, self.nder) # [TODO] check effect caused by self.DoF
        self.temp_datadict = copy.copy(temp_datadict)

        X_test = np.zeros([len(usedSampleIds)*self.DoF*self.nder, temp_datadict['PSI_X'].shape[1]]) # (18,60), np.array([[...]]) 
        y_test = np.zeros([len(usedSampleIds)*self.DoF*self.nder, temp_datadict['Y'].shape[1]]) # (18,1)
        for i in range(len(usedSampleIds)):
            indices = np.arange(self.DoF*self.nder*(usedSampleIds[i]-1)+1, self.DoF*self.nder*usedSampleIds[i]+1, dtype=float) # [X-1, X, X+1]
            indices = map(int, indices-1)
            X_test[i*self.DoF*self.nder:(i+1)*self.DoF*self.nder, :] = temp_datadict['PSI_X'].take(indices,axis=0)
            y_test[i*self.DoF*self.nder:(i+1)*self.DoF*self.nder, :] = temp_datadict['Y'].take(indices,axis=0)
        [w_starProMPs, sigma_starProMPs] = self.ProMPs_prediction(X_test, y_test, self.ProMPsPrior, lambdaProMPsPrediction, self.DoF) # w_starProMPs (60, 1) sigma_starProMPs (60, 60)
        y_predProMPs = np.dot(self.datasets_train[0]['PSI_X'], w_starProMPs) # (153, 1) # y_predProMPs = np.dot(temp_datadict['PSI_X'], w_starProMPs) # (153, 1)
        y_predProMPs = y_predProMPs[::self.nder, :] # only plot the 0-th derivative # (153, 1)
        y_predProMPsMat = np.reshape(y_predProMPs, (self.T, self.DoF)).transpose() # (3, 51) # y_predProMPsMat = np.reshape(y_predProMPs, (obs_num, self.DoF)).transpose()
        y_test = y_test[::self.nder,:] # (18, 1) # only plot the 0-th derivative
        y_testMat = np.reshape(y_test, (int(len(y_test)/float(self.DoF)), self.DoF)).transpose() # (3, 6)
        
        if _plot_: # plot the entire predicted trial, length: self.T
            self.ProMPs_plot_prediction(self.nder, y_predProMPs, sigma_starProMPs, self.lambdaProMPs, self.T, self.DoF, usedSampleIds, y_testMat, y_predProMPsMat)
        return np.transpose(y_predProMPsMat)



    def ProMPs_plot_prediction(self, nder, y_predProMPs, sigma_starProMPs, lambdaProMPs, T, DoF, usedSampleIds, y_testMat, y_predProMPsMat):
        y_predVarProMPs = np.zeros(y_predProMPs.shape)
        for t in range(y_predProMPs.shape[0]): # 0, 1, ..., y_predProMPs.shape[0]-1
            k = t*nder-(nder-1) # pick the rows of PSI_X associated with the 0-th derivative
            y_predVarProMPs[t,:] = np.dot(np.dot(self.datasets_train[0]['PSI_X'][k-1,:],sigma_starProMPs), np.transpose(self.datasets_train[0]['PSI_X'][k-1,:])) + lambdaProMPs #(153,1), use the entire PSI_X to obtain the predicted 'y' for entire trajectory
        y_predVarProMPsMat = np.reshape(y_predVarProMPs,(T,DoF)).transpose() # (3,51)

        timeIds = np.linspace(0,1,T) # (51,)
        for i in range(DoF): # plotting the entire predicted trajectory for each joint
            plt.figure()
            mean_plot = y_predProMPsMat[i,:]
            error_plot = np.sqrt(y_predVarProMPsMat[i,:])
            plt.plot(timeIds, mean_plot, 'r', linewidth=1)
            plt.fill_between(timeIds, mean_plot-error_plot, mean_plot+error_plot, alpha=0.2, edgecolor='#1B2ACC', facecolor='#089FFF', linewidth=4, antialiased=True)

            usedSampleIds = map(int, usedSampleIds)
            hObs = plt.scatter(np.transpose(timeIds.take(usedSampleIds, axis=0)), np.transpose(y_testMat[i,:])) # scatter observation
            plt.xlabel('Movement Phase', fontsize=17)
            plt.ylabel('Prediction of Joint '+str(i), fontsize=17)
            plt.show()



    def ProMPs_prediction(self, X_star, y_star, ws, lam, DoF):
        [M,N,L] = np.shape(ws)
        S = X_star.shape[0]/DoF
        flgUseRecursiveImpl = 0
        if np.shape(lam)[0]*np.shape(lam)[1] == 1:
            if flgUseRecursiveImpl:
                lambdaMat = np.identity(DoF)*lam
            else:
                lambdaMat = np.identity(DoF*S)*lam
        else:
            if flgUseRecursiveImpl:
                lambdaMat = np.diag(lam)
            else:
                lambdaMat = np.diag(np.kron(np.ones((1,S)),lam)[0])
        w_star = np.mean(ws,2)
        sigma_star = np.cov(np.squeeze(ws[:,0,:]))    
        x_tmp = np.transpose(X_star) #(60,18)
        y_tmp = y_star #(18,1)
        sigma_star = np.transpose(sigma_star) #(60,60)
        features = np.transpose(x_tmp) #(18,60)
        temp = np.linalg.inv((lambdaMat+np.dot(np.dot(features,sigma_star),np.transpose(features)))) # Eq.(5)
        tempMatrix = np.dot(np.dot(sigma_star,np.transpose(features)), temp)
        newMu = w_star + np.dot(tempMatrix,(y_tmp - np.dot(features,w_star)))
        newSigma = sigma_star - np.dot(np.dot(tempMatrix,features),sigma_star) # Eq.(6)
        return newMu, newSigma