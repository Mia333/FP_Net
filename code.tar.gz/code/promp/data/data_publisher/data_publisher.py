#!/usr/bin/env python
# Read recorded real data from .mat file and then publish it.

import rospy
import scipy.io as sio
from rospy_tutorials.msg import Floats
from rospy.numpy_msg import numpy_msg
import numpy as np

def publish_data():

    mat_content = sio.loadmat('recorded_data.mat')
    Wrist = mat_content['Wrist']
    Elbow = mat_content['Elbow']
    Shoulder = mat_content['Shoulder']

    Wrist_x = Wrist[0]
    Wrist_y = Wrist[1]
    Wrist_z = Wrist[2]

    Elbow_x = Elbow[0]
    Elbow_y = Elbow[1]
    Elbow_z = Elbow[2]

    Shoulder_x = Shoulder[0]
    Shoulder_y = Shoulder[1]
    Shoulder_z = Shoulder[2]

    n_points = len(Wrist_x)

    rospy.init_node('data_publisher', anonymous=False)
    # define publish frequency
    r = rospy.Rate(100)
    pub = rospy.Publisher('trajectory', numpy_msg(Floats), queue_size=10)

    i = 0

    try:
    	while i < n_points:
    		# generate the data array
    		data = [Wrist_x[i]/1000.0, Wrist_y[i]/1000.0, Wrist_z[i]/1000.0, Elbow_x[i]/1000.0, Elbow_y[i]/1000.0, Elbow_z[i]/1000.0, Shoulder_x[i]/1000.0, Shoulder_y[i]/1000.0, Shoulder_z[i]/1000.0]
    		data_traj = np.array(data)
    		data_traj = data_traj.astype(np.float32)

    		# publish the current observation
    		pub.publish(data_traj)
    		r.sleep()

    		i += 1
    		if i == n_points - 1:
    		 	i = 0
    		 	rospy.loginfo('replay')

    except KeyboardInterrupt:
    	pass

if __name__ == '__main__':
    
    try:
        publish_data()

    except rospy.ROSInterruptException:
        pass