clear
clc
path = pwd;
load training_dataset.mat

N = size(TrajList,1);

figure
for i=1:N
    plot(TrajList(i,:,1), TrajList(i,:,2));
    hold on
    plot(TrajList(i,end,1), TrajList(i,end,2), 'ro')
    hold on
end