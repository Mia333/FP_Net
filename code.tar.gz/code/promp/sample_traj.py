

import numpy as np

import matplotlib.pyplot as plt

import scipy.io as sio

from modProMP import classProMP


def load_data(path):
    data = sio.loadmat(path)
    data = data['TrajList']
    data = np.squeeze(data)
    return data


def load_data_old(path):
    """ For the old matlab data, in ProMPDemo folder
    """
    data = sio.loadmat(path)
    data = np.squeeze(data["T1_all"])
    data = np.stack(list(data), axis=0)
    # print(data.shape)
    return data

def back_transform(model, omega, nder=0, DoF=3):
    """ Transform a omega back to a trajectory in the original space
        omega: [num_basis_func * Dof * num_derivative]
        nder: number of derivatives, int
        DoF: degree of freedom, int
        original space trajectory: [time, DoF]
    """
    
    # for all time steps, the basis functions are identical
    PSI_X = model.datasets_train[0]['PSI_X']

    traj_flat = PSI_X.dot(omega)
    # print(traj_flat.shape)

    T = int(len(traj_flat) / DoF)
    traj = traj_flat.reshape(T, DoF)

    return traj


def sample_model_traj(model, num_samples=10, plot=False):
    """ Sample a set of trajectories from the ProMP model (and plot them)
        
        sample_trajs: [idx, time, DoF]
    """

    mu = model.omega
    Sigma = model.Sigma + np.eye(mu.shape[0]) * model.lambdaProMPs

    sample_trajs = []

    for i in range(num_samples):
        sample = np.random.multivariate_normal(np.squeeze(mu), Sigma)
        sample_trajs.append(back_transform(model, sample))
    
    if plot:
        fig = plt.figure()
        ax = fig.gca(projection='3d')
        mean_traj = back_transform(model, mu)
        ax.plot(mean_traj[:,0], mean_traj[:,1], mean_traj[:,2], c = 'r', linewidth = 3, label='mean traj')
        for sample_traj in sample_trajs:
            ax.plot(sample_traj[:,0], sample_traj[:,1], sample_traj[:,2], c = 'k',  alpha = 0.3)
        plt.title('Sampled Trajectories')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.view_init(30,120)
        plt.legend()
        plt.show()
    return np.asarray(sample_trajs)


if __name__ == "__main__":

    # data_path = './data/WOLFGANG_INT/0/training_dataset.mat'
    data_path = './data/MATLAB_ORIGINAL/T1_all_S5.mat'

    dataset = load_data_old(data_path)

    print(dataset.shape)

    model = classProMP()
    model.process_training_data(data=dataset)
    model.train_prior_model(_plot_=True)

    sample_model_traj(model, 40, plot=True)