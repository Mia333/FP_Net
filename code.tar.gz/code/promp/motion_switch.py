#!/usr/bin/env python
"""
Online motion segmentation, realize the ROS node that decides the current phase of movement according to the relative position of wrist to the 'start position' or 'target position'.
K. Yao, kunpeng.yao@tum.de
Last modified: 26. Sep. 2017
"""
import rospy
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats
from std_msgs.msg import Int32, Float32, String
from qualisys.msg import Marker, Markers, Subject
import scipy
from scipy import interpolate
import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from mpl_toolkits.mplot3d import Axes3D, proj3d
import math
import numpy as np
import numpy.matlib
from numpy import linalg as LA
import json
import os
import modProMP as mod

global motion; motion = 0 # 0: waiting # 1: from starting to reaching # 2: from end position back to start position 
global posS, posT
global _plot_; _plot_ = True

if _plot_:
	fig = plt.figure(0)
	ax = fig.add_subplot(111, aspect='equal')
	plt.hold(True)

global marker_0; marker_0 = None
global marker_1; marker_1 = None

global start_time; start_time = 0.0 # starting time, used to calculate the time duration of the motion
global motion_duration; motion_duration = 0.0 # duration of the motion. Starts at motion == 1, ends at motion == 2.

def callback_primary(msg):
	global motion, posS, posT, pub_motion, marker_0, marker_1
	global start_time, motion_duration, pub_time, pub_target
	global region_start, region_target

	marker_0 = np.array([msg.position.x/scaling_ratio, msg.position.y/scaling_ratio, msg.position.z/scaling_ratio])
	marker_1 = None # Optional: use marker_1 to increase the robustness of motion segmentation. If marker_1 is used, then the current marker position that used to segment the motion is calculated as the middle of marker_0 and marker_1.

	if marker_1 is None:
		marker_average = marker_0
	else:
		marker_average = (marker_0 + marker_1)/2.0 # take an average of the two markers

	distance_start = min( LA.norm(posS-marker_average, axis=1) ) # disatance between the current marker postion and the start position
	
	if motion == 0: # waiting
		if distance_start > region_start:
			motion = 1 # change to forward movement
			start_time = rospy.get_time() # start recording the current time

	elif motion == 1: # moving forward
		dist_vec = LA.norm(posT-marker_average, axis=1) # a vector saves the current distance to all possible targets
		distance_end = min(dist_vec) # distance to the closest target
		target_idx = np.argmin(dist_vec) # the closest target to the current marker position

		if distance_end < region_target: # close enough to the end position
			motion = 2 # backward movement
			motion_duration = rospy.get_time() - start_time
			pub_time.publish(motion_duration) # publish the motion duration (from start position to the target position)
			pub_target.publish(target_idx) # publish the index of the real target that the marker has arrived

	elif motion == 2: # backward movement
		if distance_start < region_target: # if get close to the starting position
			motion = 0 # switch to waiting status

	pub_motion.publish(motion) # publish motion type flag

	

if __name__ == '__main__':
	rospy.init_node('motion_switch', anonymous=False)

	config_file = rospy.get_param("~config_file", "")
	dir_path = os.path.dirname(os.path.realpath(__file__))
	path_to_json = dir_path + '/config/' + config_file +'.json'
	
	with open(path_to_json) as data_file:
		config_data = json.load(data_file)
	posS = np.array(config_data['Start_Positions']) # start positions of the wrist
	posT = np.array(config_data['Target_Positions']) # target positions of the wrist

	global region_start; region_start = config_data['radius_start'] # start region, i.e. if the marker is inside this region (dist.<radius_start), it is considered at the start position
	global region_target; region_target = config_data['radius_target']
	global scaling_ratio; scaling_ratio = float(config_data['scaling_ratio']) # decide if scaling of the Qualisys data is required. 1: shoud divide 1000 in the callback functions; 0: not required

	rospy.Subscriber('qualisys/wrist_right_3', Marker, callback_primary) # 'qualisys/wrist_right_3' is the used marker
	# rospy.Subscriber('qualisys/wrist1', Marker, callback_secondary)

	global pub_motion; pub_motion = rospy.Publisher('/motion_status', Int32, queue_size=10) # publish the motion status
	global pub_time; pub_time = rospy.Publisher('/motion_duration', Float32, queue_size=10) # publish the motion duration
	global pub_target; pub_target = rospy.Publisher('/target_idx', Int32, queue_size=10) # publish the index of the arrived target
	
	if _plot_: # initialize the plot
		plot_color = ["none","none","none"]
		plot_color[motion] = "green"
		p1 = patches.Rectangle((0.05, 0.05), 0.3, 0.9, facecolor=plot_color[0])
		p2 = patches.Rectangle((0.35, 0.05), 0.3, 0.9, facecolor=plot_color[1])
		p3 = patches.Rectangle((0.65, 0.05), 0.3, 0.9, facecolor=plot_color[2])
		ax.add_patch(p1)
		ax.add_patch(p2)
		ax.add_patch(p3)
		plt.show(block=False)

	try:
		while not rospy.is_shutdown():

			if _plot_:
				p1.remove()
				p2.remove()
				p3.remove()
				plot_color = ["none","none","none"]
				plot_color[motion] = "green"
				p1 = patches.Rectangle((0.05, 0.05), 0.3, 0.9, facecolor=plot_color[0])
				p2 = patches.Rectangle((0.35, 0.05), 0.3, 0.9, facecolor=plot_color[1])
				p3 = patches.Rectangle((0.65, 0.05), 0.3, 0.9, facecolor=plot_color[2])
				ax.add_patch(p1)
				ax.add_patch(p2)
				ax.add_patch(p3)
				plt.draw()
			else:
				pass

		rospy.spin()

	except rospy.ROSInterruptException:
		pass
