#!/usr/bin/env python
"""
Train and update the ProMP model and make predictions of the 'elbow' joint.
K. Yao, kunpeng.yao@tum.de
Last modified: 13. Sep. 2017
"""
import rospy
import numpy as np
import numpy.matlib
from numpy.linalg import norm

import math as math
import json
import copy
import os

import scipy
import scipy.io
from scipy import interpolate

from rospy.numpy_msg import numpy_msg
from std_msgs.msg import String, Int32
from sensor_msgs.msg import JointState # position->X, velocity->Y, effort->Z
from geometry_msgs.msg import Point
from rospy_tutorials.msg import Floats

import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D, proj3d

import modProMP as mod
from promp_multinode.srv import * # import the service file 'Predict.srv'

global motion_current; 		motion_current = 0 # current motion type
global motion_last; 		motion_last = 0 # last motion type
global ENABLE_PREDICTION; 	ENABLE_PREDICTION = False # only 'True' during forward motion
global ENABLE_UPDATE; 		ENABLE_UPDATE = False # only 'True' during backward motion
global FINISH_UPDATE; 		FINISH_UPDATE = False # indicate if the update is already finished (True) or not (False)
global FINISH_PREDICT; 		FINISH_PREDICT = False
global pred_idx; 			pred_idx = -1 # predicted index of the trajectory
global real_idx;			real_idx = -1 # index of real target
global IDX_UPDATED; 		IDX_UPDATED = False
global xmax, xmin, ymax, ymin, zmax, zmin, elev, azim # workspace description
global JS_predict, JS_prior # msg to publish

def scatter_points(point_array, ax, point_title, plot_color = 'k', plot_size = 50): # point_array: N*3
	for i in range(point_array.shape[0]):
		ax.scatter(point_array[i,0], point_array[i,1], point_array[i,2], c=plot_color, s=plot_size, lw=0)
		ax.text(point_array[i,0], point_array[i,1], point_array[i,2]+0.01, point_title+' '+str(i+1), color=plot_color)



def cb_motion(msg): # change flags according to different motion type
	global motion_last, motion_current, ENABLE_PREDICTION, ENABLE_UPDATE, FINISH_UPDATE
	motion_current = msg.data
	if motion_last == motion_current: # during a motion, no change of state
		pass
	else:
		if motion_last == 0 and motion_current == 1: # switch to forward motion, enable prediction, disable update
			ENABLE_PREDICTION = True
			ENABLE_UPDATE = False
		elif motion_last == 1 and motion_current == 2: # switch to backward motion, disable prediction, enable update
			ENABLE_PREDICTION = False
			ENABLE_UPDATE = True
		elif motion_last == 2 and motion_current == 0: # move back to starting position, reset all flags
			ENABLE_PREDICTION = False
			ENABLE_UPDATE = False
		else:
			rospy.logerr('[EL] Error: promp_elbow::cb_motion', motion_last, motion_current)
	motion_last = motion_current



def cb_target(msg):
	global real_idx
	real_idx = msg.data



def	plot_setting(plt, ax, title_name):
	plt.title(title_name)
	ax.set_xlabel('X')
	ax.set_ylabel('Y')
	ax.set_zlabel('Z')
	ax.set_xlim(xmin, xmax)
	ax.set_ylim(ymin, ymax)
	ax.set_zlim(zmin, zmax)
	ax.view_init(elev, azim)
	plt.tight_layout()
	plt.gca().invert_xaxis()
	plt.gca().invert_zaxis() # to match the CF in the real scenario
	plt.show(block=False)
	return plt, ax


def draw_sphere(plt, ax, ctr_mtx, r, c='b'):
	# ctr: center of the sphere, 3D coordinates.
	# r: radius
	for i in xrange(ctr_mtx.shape[0]): # number of centers
		ctr = ctr_mtx[i]
		u = np.linspace(0, 2 * np.pi, 500)
		v = np.linspace(0, np.pi, 500)
		x = r * np.outer(np.cos(u), np.sin(v)) + ctr[0]
		y = r * np.outer(np.sin(u), np.sin(v)) + ctr[1]
		z = r * np.outer(np.ones(np.size(u)), np.cos(v)) + ctr[2]
		ax.plot_surface(x, y, z, color=c, alpha = 0.3, linewidth=0)
	return plt, ax


'''---------- Service Functions ----------'''
def srv_prediction(req):
	global predict_mtx
	global posS, posT

	ts = req.ts # time_steps (19)
	md = req.md # motion duration (10)
	res = PredictResponse()
	
	if predict_mtx is None: # prediction is not finished
		rospy.logwarn("srv_prediction: predict_mtx: None")
		predict_mtx = np.zeros((51,3))
	
	# ---------- Process Prediction Matrix ----------
	if req.predictionType == 0:
		if sum(sum(predict_mtx)) == 0:
			rospy.logwarn("srv_prediction: predict_mtx: not updated")
		else:
			rospy.loginfo("srv_prediction: predict_mtx: updated")
		res.traj_wrist = []
		res.traj_elbow = []

		# ----- Interpolation of the Prediction Result to Adapt to the Required Data Length -----
		pred_ts = predict_mtx.shape[0] # length of original prediction
		x = predict_mtx[:,0]
		y = predict_mtx[:,1]
		z = predict_mtx[:,2]
		t = np.arange(0, pred_ts)

		f_x = interpolate.interp1d(t, x)
		f_y = interpolate.interp1d(t, y)
		f_z = interpolate.interp1d(t, z)
		t_new = np.linspace(0, pred_ts-1, ts+1)

		x_down = f_x(t_new) # ts+1 * 1
		y_down = f_y(t_new) # ts+1 * 1
		z_down = f_z(t_new) # ts+1 * 1
		
		for i in range(x_down.shape[0]):
			temp_wrist = Point()
			# creat the trajectory of wrist
			temp_wrist.x = x_down[i]
			temp_wrist.y = -y_down[i]
			temp_wrist.z = -(z_down[i]+0.35) # offset in Z direction 
			res.traj_wrist.append(temp_wrist)
			# creat the trajectory of elbow (elbow is not used here rather only created based on the point of wrist)
			temp_elbow = copy.copy(temp_wrist)
			temp_elbow.y = temp_elbow.y - 0.2 # 20 cm offset between wrist and elbow (length of the arm)
			temp_elbow.z = temp_elbow.z - 0.1 # 10 cm offset in the Z direction
			res.traj_elbow.append(temp_elbow)
		res.traj_wrist = res.traj_wrist[::-1] # reverse the time sequence
		res.traj_elbow = res.traj_elbow[::-1]

	elif req.predictionType in [1,2]: # 'predictionType' should be '0', prediction without Vel. Acc.
		rospy.logwarn('req.predictionType: %i', req.predictionType)
		raise NotImplementedError

	elif req.predictionType == 3: # predictionType = 3: No prediction: just assume a point on the [0,0,0] point
		res.traj_wrist = []
		res.traj_elbow = []
		for i in range(ts+1):
			temp_wrist = Point()
			temp_wrist.x = 0
			temp_wrist.y = 0
			temp_wrist.z = 0
			res.traj_wrist.append(temp_wrist)
			temp_elbow = copy.copy(temp_wrist)
			res.traj_elbow.append(temp_elbow)
		res.traj_wrist = res.traj_wrist[::-1] # reverse the time sequence
		res.traj_elbow = res.traj_elbow[::-1]

	else:
		raise NotImplementedError

	rospy.loginfo("req.predictionType:0 %i", req.predictionType)
	# print 'res.traj_wrist: ', res.traj_wrist
	# print 'res.traj_elbow: ', res.traj_elbow
	print '---------- ---------- ---------- ---------- ----------'
	
	return res



if __name__ == '__main__':
	rospy.init_node('promp_elbow', anonymous=True)

	global predict_mtx; predict_mtx = None # prediction result in the current loop
	global prior_mtx; 	prior_mtx = None # trained prior trajectory of the current model

	config_file = rospy.get_param("~config_file", "")
	dir_path = os.path.dirname(os.path.realpath(__file__))
	path_to_json = dir_path + '/' + config_file +'.json'

	with open(path_to_json) as data_file:
		config_data = json.load(data_file)

	global posS; posS = np.array(config_data['Start_Positions'])
	global posT; posT = np.array(config_data['Target_Positions'])
	
	# find the min. and max. values of start and end position in each axis, used as the range of plotting
	fix_points = np.append(posS, posT, axis=0)
	xmin = np.min(fix_points[:,0]); xmax = np.max(fix_points[:,0])
	ymin = np.min(fix_points[:,1]); ymax = np.max(fix_points[:,1])
	zmin = np.min(fix_points[:,2]); zmax = np.max(fix_points[:,2])
	zmin -= 0.1
	zmax += 0.1

	[elev, azim] = config_data['view']
	plot_train_traj = config_data['plot_train_traj']
	plot_prior_traj = config_data['plot_prior_traj']
	radius_start = config_data['radius_start']
	radius_target = config_data['radius_target']

	numS = posS.shape[0] # number of Start positions
	numT = posT.shape[0] # number of End positions, i.e. num of targets

	ModelList = [] # create a list for multiple models

	if config_file == 'single_target':
		model_name = 'SINGLE' # 'model_name' indicates the name of the folder that saves the training dataset, 'SINGLE' for Omer Can Sari's ptomp project
	elif config_file == 'multiple_targets':
		model_name = 'EL' # 'EL' for Omar Kamal's project.
	else:
		rospy.logerr('Invalid Configuration File Name: %s', config_file)
		raise NotImplementedError

	for i in range(numT):
		temp_model = mod.classProMP(config_file, model_name, i, '/qualisys/elbow_right_3')
		ModelList.append(temp_model)

	rospy.Subscriber('/motion_status', Int32, cb_motion) # initialize subscriber, sub. to the current motion status, 0: at the start position, 1: between start pos and target pos, 2: arrived at target pos.
	rospy.Subscriber('/target_idx', Int32, cb_target) # initialize subscriber, sub. to the index of the real arrived target
	
	pub_prior = rospy.Publisher('/prior_trajectory_elbow', numpy_msg(Floats), queue_size=10)
	pub_predict = rospy.Publisher('/predict_trajectory_elbow', numpy_msg(Floats), queue_size=10)

	pubJS_prior = rospy.Publisher('/JS_prior_elbow', JointState, queue_size=10) # reformulate the msg as 'JointState' msg type and publish it
	pubJS_predict = rospy.Publisher('/JS_predict_elbow', JointState, queue_size=10) # reformulate the msg as 'JointState' msg type and publish it

	srvPredict = rospy.Service('predictionNode', Predict, srv_prediction) # ROS Service

	for i in range(numT):
		ModelList[i].process_training_data(_plot_=plot_train_traj)
		ModelList[i].train_prior_model(_plot_=plot_prior_traj) # train prior model using the data from 'training_dataset.mat'
		if ModelList[i].TrajPrior is None:
			rospy.loginfo('[%s] Error: train_prior_model', model_name)

	rospy.loginfo('[%s] --- Prior Model Trained ---', model_name)

	fig = plt.figure(0)
	ax = fig.gca(projection='3d')
	plt.hold(True)
	ms = 10 # markersize
	lw = 5 # line width
	
	plt, ax = plot_setting(plt, ax, 'Predicted and Updated Trajectory: Elbow')

	scatter_points(posS, ax, 'Start', plot_color = 'r', plot_size = 50)
	scatter_points(posT, ax, 'Target',plot_color = 'g', plot_size = 50)

	# plt, ax = draw_sphere(plt, ax, posS, radius_start, c='b') # draw the region of the start position
	# plt, ax = draw_sphere(plt, ax, posT, radius_target, c='r') # draw the region of the start position

	try:
		freq_counter = 0
		freq_prediction = 0 # number of prediction
		r = rospy.Rate(20) # 5s for 50 sampled observation points, freq. = 10 Hz

		while not rospy.is_shutdown():

			'''
			Forward Movement: Make Prediction
			'''
			if ((ENABLE_PREDICTION == True) and (ENABLE_UPDATE == False)): # 0 -> 1: during forward movement, making predictions
				for i in range(numT):
					if (ModelList[i].obs_list is None) or (ModelList[i].obs_list.shape[0] <= ModelList[i].nder+1):
						ModelList[i].append_observation() # Append observation to the list # [remark] must more than 2 observations to enable vel.

				promp = ModelList[0] # Just for plotting trajectory. ModelList[0] and ModelList[1] record the same obs. trajectory.
				if freq_counter < 2:
					freq_counter += 1					
					for i in range(numT):
						ModelList[i].append_observation()
					ax.scatter(promp.obs_list[-1,0], promp.obs_list[-1,1], promp.obs_list[-1,2], c = 'k', s = 10) # real time trajectory
				else:
					for i in range(numT):
						ModelList[i].append_observation()
					ax.scatter(promp.obs_list[-1,0], promp.obs_list[-1,1], promp.obs_list[-1,2], c = 'k', s = 10) # real time trajectory
					freq_prediction += 1
					if (not FINISH_PREDICT): # if freq_prediction%5 == 0:
						ax.clear()
						plt, ax = plot_setting(plt, ax, 'Predicted and Updated Trajectory: Elbow')
						scatter_points(posS, ax, 'Start', plot_color = 'r', plot_size = 50)
						scatter_points(posT, ax, 'Target', plot_color = 'g', plot_size = 50)

						# ---------- Prediction & Decision using Cosine Similarity ----------
						PredictList = [] # A list to save all the predictions
						DistanceList = [] # A list to save the metric between the observation list and the prior distribution
						temp_obs_list = ModelList[0].obs_list # Same as ModelList[1]
						for i in range(numT):
							temp_predict = ModelList[i].make_prediction()
							PredictList.append(temp_predict)
						
							# --------------------------------------------------
							if ModelList[i].TrajPrior is None:
								rospy.logerr('[%s] Error: ModelList[i].TrajPrior is None %s', model_name, i)
							else:
								VecObs = ModelList[0].obs_list[-1,:] - posS # np.array([[X,Y,Z]]) # Using cosine similarity Vec(posS, Obs) and Vec(posS, posT[i])
								VecEnd = posT[i] - posS # np.array([[X,Y,Z]])
								temp_dist = np.dot(VecObs[0], VecEnd[0])/(norm(VecEnd[0])*norm(VecObs[0])) # in fact, 'temp_dist' should be temp_cosine similairity # [Alternative] temp_dist = dtw(temp_obs_list, ModelList[i].TrajPrior) # calculate the DTW between the obs_list and the prior traj.
								DistanceList.append(temp_dist)
						pred_idx = np.argmax(DistanceList) # predicted real index (pred_idx) of the target. argmax for cos similarity, argmin for Eucledian dist.

						FINISH_PREDICT = True
						predict_mtx = PredictList[pred_idx]
						
						pub_predict.publish(np.array(np.reshape(predict_mtx, (predict_mtx.size, )), dtype=numpy.float32)) # Publish the predicted trajectory
						global JS_predict; JS_predict = JointState() # publish predicted trajectory as 'JointState' type

						JS_predict.name = str(pred_idx)
						JS_predict.position = predict_mtx[:,0] # X coordinates
						JS_predict.velocity = predict_mtx[:,1] # Y coordinates
						JS_predict.effort = predict_mtx[:,2] # Z coordinates

						pubJS_predict.publish(JS_predict)

						ax.plot(predict_mtx[:,0], predict_mtx[:,1], predict_mtx[:,2], color = 'c', linewidth = 3, label = 'Predicted Trajectory: Elbow') # plot prediction
						ax.legend()
						ax.scatter(ModelList[pred_idx].obs_list[-1,0], ModelList[pred_idx].obs_list[-1,1], ModelList[pred_idx].obs_list[-1,2], c = 'y', s = 100, linewidth=0)
						ax.text(ModelList[pred_idx].obs_list[-1,0], ModelList[pred_idx].obs_list[-1,1], ModelList[pred_idx].obs_list[-1,2]+0.01, 'obs', color='y')

						rospy.loginfo('[%s] promp.make_prediction', model_name) # should be around 50 for a trial of 5 sec.
					freq_counter = 0
				FINISH_UPDATE = False

			'''
			Backward Movement: Save Observation and Update Model
			'''
			elif ((ENABLE_PREDICTION == False) and (ENABLE_UPDATE == True)): # 1 -> 2: during backward movement, load local observation file, update ProMP model
				# num_prediction = 0 # reset number of prediction
				freq_prediction = 0

				if not FINISH_UPDATE: # make sure that update is only executed once at this state (ENABLE_UPDATE & ~ENABLE_PREDICTION)
					if pred_idx < 0: # index has not been initialized yet (Update process happend before Prediction process)
						rospy.logerr('[%s] Error: pred_idx: %s', model_name, pred_idx)
					else:
						if real_idx < 0: # not initialized yet, i.e. no real target has been reached
							rospy.logerr('[%s] Error: real_idx: %s', model_name, real_idx)
						else:
							if pred_idx == real_idx: # real taget & predicted target are the same, i.e. prediction is correct, update the model
								ModelList[pred_idx].save_motion_trial() # Save the motion trial to the corresponding Model
								rospy.loginfo('[%s] promp.save_motion_trial', model_name)
								prior_mtx = ModelList[pred_idx].update_model() # Using the new saved obs. list to update the prior distribution
								rospy.loginfo('[%s] promp.update_model', model_name)

								# --------------------------------------------------
								pub_prior.publish(np.array(np.reshape(prior_mtx, (prior_mtx.size, )), dtype=numpy.float32))
								global JS_prior; JS_prior = JointState() # publish prior trajectory as 'JointState' type

								JS_prior.name = str(pred_idx)
								JS_prior.position = prior_mtx[:,0] # X coordinates
								JS_prior.velocity = prior_mtx[:,1] # Y coordinates
								JS_prior.effort = prior_mtx[:,2] # Z coordinates
								pubJS_prior.publish(JS_prior)

								ax.plot(prior_mtx[:,0], prior_mtx[:,1], prior_mtx[:,2], color = 'm', linewidth = 3, label = 'Updated ProMP Prior: Elbow') # plot prior distribution
								ax.legend()
								FINISH_UPDATE = True
								FINISH_PREDICT = False

							else:
								FINISH_UPDATE = True
								FINISH_PREDICT = False
								rospy.logwarn('[%s] Model Not Updated: promp_elbow: pred_idx != real_idx', model_name)
						
					for i in range(numT):
						ModelList[i].obs_list = None # reset observation list for a new trial
				else:
					pass
					
			# --------------------------------------------------
			else:
				# num_prediction = 0 # reset number of prediction
				freq_prediction = 0
				FINISH_UPDATE = False
			plt.draw()
			# r.sleep()
		rospy.spin()

	except KeyboardInterrupt:
		raise
