#!/usr/bin/env python
"""
Plot the real-time trajectory of the joint.
K. Yao, kunpeng.yao@tum.de
Last modified: 13. Sep. 2017
"""
import rospy
import numpy as np
import numpy.matlib
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats
from qualisys.msg import Marker, Markers, Subject
from std_msgs.msg import String, Int32
import scipy
import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D, proj3d
import modProMP as mod
import math
import copy
import json
import os

fig = plt.figure(0)
ax = fig.add_subplot(111, projection='3d')
plt.hold(True)

global ms; ms = 5 # markersize, for 'plot'
global lw; lw = 5 # linewidth
global xmax, xmin, ymax, ymin, zmax, zmin, elev, azim # Workspace Description



def draw_sphere(plt, ax, ctr_mtx, r, c='b'):
	# ctr: center of the sphere, 3D coordinates.
	# r: radius
	for i in xrange(ctr_mtx.shape[0]): # number of centers
		ctr = ctr_mtx[i]

		u = np.linspace(0, 2 * np.pi, 500)
		v = np.linspace(0, np.pi, 500)
		x = r * np.outer(np.cos(u), np.sin(v)) + ctr[0]
		y = r * np.outer(np.sin(u), np.sin(v)) + ctr[1]
		z = r * np.outer(np.ones(np.size(u)), np.cos(v)) + ctr[2]

		ax.plot_surface(x, y, z, color=c, alpha = 0.3, linewidth=0)
	return plt, ax



def scatter_points(point_array, ax, point_title, plot_color = 'k', plot_size = 50): # point_array: N*3
	for i in range(point_array.shape[0]):
		ax.scatter(point_array[i,0], point_array[i,1], point_array[i,2], c=plot_color, s=plot_size, lw=0)
		ax.text(point_array[i,0], point_array[i,1], point_array[i,2]+0.01, point_title+' '+str(i+1), color=plot_color)



def plot_setting(plt, ax, title_name): # def plot_setting(plt, ax, title_name, xmin=-0.7, xmax=0.1, ymin=-1.1, ymax=0.2, zmin=1.0, zmax=1.5):
	plt.title(title_name)
	ax.set_xlabel('X')
	ax.set_ylabel('Y')
	ax.set_zlabel('Z')
	ax.set_xlim(xmin, xmax)
	ax.set_ylim(ymin, ymax)
	ax.set_zlim(zmin, zmax)
	ax.view_init(elev, azim)
	plt.tight_layout()
	plt.gca().invert_xaxis() # to match the CF in the real scenario
	plt.gca().invert_zaxis() # to match the CF in the real scenario
	plt.show(block=False)
	return plt, ax



global TrajList; TrajList = None
global plot_traj; plot_traj = False # Flag, decide if plot current trajectory
global traj_saved; traj_saved = False # Flag, True: if trajectory of forward movement is saved, False otherwise
global clear_screen; clear_screen = False # Flag, used to decide if clear the screen. True, if last_motion = 2 and current_motion = 0 (backward movement to the original position)
global last_motion; last_motion = -1

global WR; WR = np.array([0.0, 0.0, 0.0]) # Wrist
global EL; EL = np.array([0.0, 0.0, 0.0]) # Elbow
global SH; SH = np.array([0.0, 0.0, 0.0]) # Shoulder

global Traj_Update; Traj_Update = np.zeros((3,50))
global Traj_Pred; Traj_Pred = np.zeros((3,50))



def cb_motion_type(msg):
	global TrajList, plot_traj, traj_saved, clear_screen, last_motion
	if msg.data == 1: # record Traj only during forward movement
		plot_traj = True
	elif msg.data == 2: # backward movement: save trajectory to mat file, clear all plotted trakjecotry
		plot_traj = False
	else: # motion_type = 0, waiting
		plot_traj = False
	# decide if clear the screen
	if msg.data == 0 and last_motion == 2: # from 'backward motion' to 'waiting state', clear the screen
		clear_screen = True
	elif msg.data == 1 and last_motion == 0:
		clear_screen = False
	elif msg.data == 2 and last_motion == 1:
		clear_screen = False
	else:
		pass
	last_motion = msg.data # update the last_motion flag



def cbWR(msg): # wrist joint
	global WR; WR = np.array([msg.position.x/scaling_ratio, msg.position.y/scaling_ratio, msg.position.z/scaling_ratio])



def cbEL(msg): # elbow joint
	global EL; EL = np.array([msg.position.x/scaling_ratio, msg.position.y/scaling_ratio, msg.position.z/scaling_ratio])



def cbSH(msg): # shoulder joint
	global SH; SH = np.array([msg.position.x/scaling_ratio, msg.position.y/scaling_ratio, msg.position.z/scaling_ratio])



def cb_updated_prior(msg):
	global Traj_Update
	Traj_Update = msg.data
	Traj_Update = np.reshape(Traj_Update.transpose(), (Traj_Update.size/3, 3)) # np.ndarray, (3, 51)



def cb_pred_traj(msg):
	global Traj_Pred
	Traj_Pred = msg.data
	Traj_Pred = np.reshape(Traj_Pred.transpose(), (Traj_Pred.size/3, 3)) # np.ndarray, (3, 51)



if __name__ == '__main__':
	rospy.init_node('promp_plot', anonymous=True)

	config_file = rospy.get_param("~config_file", "")
	dir_path = os.path.dirname(os.path.realpath(__file__))
	path_to_json = dir_path + '/config/' + config_file +'.json'

	# ---------- load configuration data (starting points and target points) ----------
	with open(path_to_json) as data_file:
		config_data = json.load(data_file)
	# posS = (np.array(config_data['posS_WR0']) + np.array(config_data['posS_WR1']))/2.0 # start positions of the wrist
	# posT = (np.array(config_data['posT_WR0']) + np.array(config_data['posT_WR1']))/2.0 # target positions of the wrist
	posS = np.array(config_data['Start_Positions']) # start positions of the wrist
	posT = np.array(config_data['Target_Positions']) # target positions of the wrist

	radius_start = config_data['radius_start']
	radius_target = config_data['radius_target']
	global NumJoints; NumJoints = config_data['NumJoints']
	global scaling_ratio; scaling_ratio = float(config_data['scaling_ratio']) # decide if scaling of the Qualisys data is required. 1: shoud divide 1000 in the callback functions; 0: not required.

	# specifications for plotting
	fix_points = np.append(posS, posT, axis=0)
	xmin = np.min(fix_points[:,0]); xmax = np.max(fix_points[:,0])
	ymin = np.min(fix_points[:,1]); ymax = np.max(fix_points[:,1])
	zmin = np.min(fix_points[:,2]); zmax = np.max(fix_points[:,2])
	zmin -= 0.1
	zmax += 0.1

	[elev, azim] = config_data['view']

	scatter_points(posS, ax, 'Start', plot_color = 'r', plot_size = 50)
	scatter_points(posT, ax, 'Target',plot_color = 'g', plot_size = 50)

	# rospy.Subscriber('qualisys/wrist0', Marker, cbWR) # 'c'
	rospy.Subscriber('/qualisys/wrist_right_3', Marker, cbWR) # 'c'
	if NumJoints == 3:
		rospy.Subscriber('/qualisys/elbow0', Marker, cbEL) # 'm'
		rospy.Subscriber('/qualisys/shoulder0', Marker, cbSH) # 'y'

	rospy.Subscriber('/motion_status', Int32, cb_motion_type)
	rospy.Subscriber('/predict_trajectory', numpy_msg(Floats), cb_pred_traj)
	rospy.Subscriber('/prior_trajectory', numpy_msg(Floats), cb_updated_prior)

	wr_pos, = ax.plot([WR[0],WR[0]], [WR[1],WR[1]], [WR[2],WR[2]], 'co', markersize=ms, label = 'Wrist', linestyle = 'None', alpha = 0.0) # Center of the Body
	if NumJoints == 3:
		el_pos, = ax.plot([EL[0],EL[0]], [EL[1],EL[1]], [EL[2],EL[2]], 'mo', markersize=ms, label = 'Elbow', linestyle = 'None', alpha = 0.0) # Center of the Body
		sh_pos, = ax.plot([SH[0],SH[0]], [SH[1],SH[1]], [SH[2],SH[2]], 'yo', markersize=ms, label = 'Shoulder', linestyle = 'None', alpha = 0.0) # Center of the Body
	
	ax.legend()

	ax.plot(Traj_Update[:,0], Traj_Update[:,1], Traj_Update[:,2], color='r', linewidth=5)
	ax.plot(Traj_Pred[:,0], Traj_Pred[:,1], Traj_Pred[:,2], color='g', linewidth=5)

	plt, ax = plot_setting(plt, ax, 'Real Time Marker Motion Visualization')
	# plt, ax = draw_sphere(plt, ax, posS, radius_start, c='b') # draw the region of the start position
	# plt, ax = draw_sphere(plt, ax, posT, radius_target, c='r') # draw the region of the start position

	try:
		while not rospy.is_shutdown():

			ax.lines.remove(wr_pos)
			
			if NumJoints == 3:
				ax.lines.remove(el_pos)
				ax.lines.remove(sh_pos)
			
			wr_pos, = ax.plot([WR[0],WR[0]], [WR[1],WR[1]], [WR[2],WR[2]], 'co', markersize=ms)
			if NumJoints == 3:
				el_pos, = ax.plot([EL[0],EL[0]], [EL[1],EL[1]], [EL[2],EL[2]], 'mo', markersize=ms)
				sh_pos, = ax.plot([SH[0],SH[0]], [SH[1],SH[1]], [SH[2],SH[2]], 'yo', markersize=ms)
			
			if plot_traj:
				ax.plot([WR[0],WR[0]], [WR[1],WR[1]], [WR[2],WR[2]], 'c.', markersize=ms)
				if NumJoints == 3:
					ax.plot([EL[0],EL[0]], [EL[1],EL[1]], [EL[2],EL[2]], 'm.', markersize=ms)
					ax.plot([SH[0],SH[0]], [SH[1],SH[1]], [SH[2],SH[2]], 'y.', markersize=ms)

			if clear_screen: # clear plotted trajectories
				ax.clear()
				plt, ax = plot_setting(plt, ax, 'Real Time Marker Motion Visualization')

				wr_pos, = ax.plot([WR[0],WR[0]], [WR[1],WR[1]], [WR[2],WR[2]], 'co', markersize=ms, label = 'Wrist')
				if NumJoints == 3:
					el_pos, = ax.plot([EL[0],EL[0]], [EL[1],EL[1]], [EL[2],EL[2]], 'mo', markersize=ms, label = 'Elbow')
					sh_pos, = ax.plot([SH[0],SH[0]], [SH[1],SH[1]], [SH[2],SH[2]], 'yo', markersize=ms, label = 'Shoulder')
				
				ax.legend()

				ax.plot(Traj_Update[:,0], Traj_Update[:,1], Traj_Update[:,2], color='r', linewidth=5) # ax.lines.remove(h_traj_update)
				ax.plot(Traj_Pred[:,0], Traj_Pred[:,1], Traj_Pred[:,2], color='g', linewidth=5) # ax.lines.remove(h_traj_pred)

				scatter_points(posS, ax, 'Start', plot_color = 'r', plot_size = 50)
				scatter_points(posT, ax, 'Target', plot_color = 'g', plot_size = 50)

			plt.draw()

		rospy.spin()

	except KeyboardInterrupt:
		raise